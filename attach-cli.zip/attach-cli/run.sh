#!/bin/bash
java Attach
echo pause
read -n 1

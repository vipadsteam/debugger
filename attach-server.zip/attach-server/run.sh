java -Djava.ext.dirs=. -jar JavaAgentServer.jar
echo pause
read -n 1
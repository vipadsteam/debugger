java -Djava.ext.dirs=. Attach
echo pause
read -n 1